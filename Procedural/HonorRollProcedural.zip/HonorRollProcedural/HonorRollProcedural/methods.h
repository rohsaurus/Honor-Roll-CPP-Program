﻿#pragma once
#include <iostream>


// Methods
void honor_roll_eligibility_checker(int number, std::string name);